/* These are the structures for the IP, TCP and ICMP headers */
/* $Id: tcpip.h,v 1.5 1998/09/22 20:35:43 savage Exp $ */
typedef struct
  {
    unsigned char vh;
    unsigned char stype;
    u_int16_t length;
    u_int16_t ident;
    u_int16_t frag;
    unsigned char ttl;
    unsigned char protocol;
    u_int16_t cksum;
    struct in_addr sip;
    struct in_addr dip;
  }
iprec;

typedef struct
  {
    u_int16_t sport;
    u_int16_t dport;
    u_int32_t seqnum;
    u_int32_t acknum;
    unsigned char txoff;
    unsigned char flags;
    u_int16_t window;
    u_int16_t cksum;
    u_int16_t urgentptr;
  }
tcprec;

typedef struct
  {
    struct in_addr sip;
    struct in_addr dip;
    unsigned char zero;
    unsigned char proto;
    u_int16_t tcplen;
  }
tcpsrec;

typedef struct
  {
    unsigned char type;
    unsigned char code;
    u_int16_t cksum;
    u_int32_t zero;
    iprec ip;
    u_int16_t sport;
    u_int16_t dport;
    u_int32_t seq;
  }
icmprec;

/* #define's for the TCP flags */
#define YYY 0x80
#define XXX 0x40
#define URG 0x20
#define ACK 0x10
#define PSH 0x08
#define RST 0x04
#define SYN 0x02
#define FIN 0x01

/* Structure for a spoofed connection */
typedef struct
  {
    struct sockaddr_in from;
    struct sockaddr_in dest;
    u_int16_t sport;
    u_int16_t dport;
    u_int32_t seq;
    u_int32_t ack;
  }
spoofrec;

/* -------------- Prototiping --------------- */
void init_tcpip(void);
int init_pcap(char*);
u_int16_t in_cksum (u_int16_t *, int);  
void sendip (spoofrec *, char *, short, short *, short *, short);
u_int16_t tcpcksum (spoofrec *, char *, short);
short resolve_host (char *, struct sockaddr_in *);
short gettcp (spoofrec *, tcprec *);
void sendtcp (spoofrec *, u_int16_t, short); 
void sendicmp (spoofrec *, struct sockaddr_in *, u_int16_t);
struct in_addr getlocalip (u_int32_t dest);
char *tcpip_id(void);

